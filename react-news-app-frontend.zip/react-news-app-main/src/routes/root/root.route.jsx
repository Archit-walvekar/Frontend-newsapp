import React from 'react';
import HomePage from '../../pages/home/home-page';

function Root() {
    return (
        <>
            <HomePage />
        </>
    )
}

export default Root;
