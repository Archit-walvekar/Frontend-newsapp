import React from 'react';
import Article from '../../pages/article/article';

function ArticleRoute() {
    return (
        <>
            <Article />
        </>
    )
}

export default ArticleRoute;
